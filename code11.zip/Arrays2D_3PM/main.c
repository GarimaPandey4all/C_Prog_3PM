#include <stdio.h>
#include <stdlib.h>

// {1, 2, 3, 4, 5, 6}

int main()
{
    int arr[2][3] = {{1, 2, 3},
                     {4, 5, 6}};
    int i, j;

    printf("Values in 2D array are:\n");
    for(i = 0; i < 2; i++)
    {
        for(j = 0; j < 3; j++)
        {
            printf("%d\t", arr[i][j]);
        }

        printf("\n");
    }

    return 0;
}
