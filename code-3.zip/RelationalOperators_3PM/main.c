#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("A==B: %d\n", (a == b));
    printf("A!=B: %d\n", (a != b));
    printf("A>B: %d\n", (a > b));
    printf("A<B: %d\n", (a < b));
    printf("A>=B: %d\n", (a >= b));
    printf("A<=B: %d\n", (a <= b));

    return 0;
}
