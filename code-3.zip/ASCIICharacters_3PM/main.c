#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter any character:");
    scanf("%c", &ch);

    printf("Entered Character = %c decimal value is:%d",ch,ch);

    //printf("Character is: %d", ch);

    return 0;
}
