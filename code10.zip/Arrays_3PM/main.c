#include <stdio.h>
#include <stdlib.h>

//Arrays: it is used store multiple values of a same type.
// Arrays is a collection of similar types of data.

int main()
{
    // 1-D : 1 Dimensional Array

    //Traditional way of array
    int arr[5] = {10, 20, 30, 40, 50}; //Array Declaration
    //[]-> square brackets/Subscript Operator // 5->size of the array
    int i;

    /*
    printf("First value of Array: %d\n", arr[0]);
    printf("Second value of Array: %d\n", arr[1]);
    printf("Third value of Array: %d\n", arr[2]);
    printf("Fourth value of Array: %d\n", arr[3]);
    printf("Fifth value of Array: %d\n", arr[4]);
    */
    printf("Values in Array are:\n");
    for(i=0; i<5; i++)
    {
        printf("%d\n", arr[i]);
    }

    return 0;
}
