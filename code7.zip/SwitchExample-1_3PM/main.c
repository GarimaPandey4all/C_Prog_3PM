#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;
    char ch;

    printf("Enter any operator:");
    scanf("%c", &ch);

    printf("Enter any value for a:");
    scanf("%d", &a);

    printf("Enter any value for b:");
    scanf("%d", &b);

    switch(ch)
    {
    case '+':
        printf("Addition is:%d\n", a+b);
        break;

    case '-':
        printf("Subtraction is:%d\n", a-b);
        break;

    case '*':
        printf("Multiplication is:%d\n", a*b);
        break;

    case '/':
        printf("Division is:%d\n", a/b);
        break;

    default:
        printf("Invalid Choice");

    }

    return 0;
}
