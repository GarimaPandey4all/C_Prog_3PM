#include <stdio.h>
#include <stdlib.h>

/*
    Three types of Loops:

    1. For Loop

        for(Initialization; Condition; Increment/Decrement)
        {

        }

    2. While Loop

        Initialization;

        while(Condition)
        {
            Increment/Decrement
        }

    3. Do-While Loop

        Initialization;

        do
        {
            Increment/Decrement
        }while(Condition);

*/

int main()
{

    for(int i=1; i<=5; i++)
    {
        printf("Hello world!\n");
    }

    return 0;
}
