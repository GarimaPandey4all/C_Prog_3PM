#include <stdio.h>
#include <stdlib.h>

/*
    while(1)
    {
        //infinite loop
    }

    for(;;)
    {
        //infinite loop
    }
*/

int main()
{
    int i = 1;

    while(i <= 10)
    {
       printf("Counter is: %d\n", i);
       i++;
    }

    return 0;
}
