#include <stdio.h>
#include <stdlib.h>

/*
    malloc():

    malloc stands for memory alocation.

    The malloc() function reserves a block of memory of the specified number of bytes.
    And, it returns a pointer of void which can be casted into pointers of any form/type.

    Syntax:
    ptr = (castype *) malloc(size);
*/


int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    text = (char *)malloc(size * sizeof(char)); // char - 1 byte // 2 * 1 = 3 bytes

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" ");
        gets(text);

        printf("Inputtted text is: %s", text);
    }

    free(text);
    text = NULL;

    return 0;
}
