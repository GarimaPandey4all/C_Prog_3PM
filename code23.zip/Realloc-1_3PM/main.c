#include <stdio.h>
#include <stdlib.h>

/*
    Realloc()

    If the dynamically allocated memory is insufficient or more than required, you can
    change the size of previously allocated memory using the realloc() function.

    Syntax:

    ptr = realloc(ptr, x);
*/

int main()
{
    char *str;

    str = (char *)malloc(15);

    strcpy(str, "jason");

    printf("String = %s and Address = %u\n", str, str);

    str = realloc(str, 25);

    strcat(str, ".com");

    printf("String = %s and Address = %u\n", str, str);

    free(str);
    str = NULL;

    return 0;
}
