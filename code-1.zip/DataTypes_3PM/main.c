#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10; // int size: 2 or 4 bytes
    float b = 24.35f; // float size: 4 bytes
    double c = 23.67; // double size: 8 bytes
    char ch = 'F'; // char size: 1 byte

    printf("Int is:%d\n", a); //Escape Characters: \n -->new line character

    printf("float is:%f\n", b);

    printf("double is:%lf\n", c);

    printf("char is:%c\n", ch);

    //sizeof()

    printf("Size of Int is:%d\n", sizeof(a));
    printf("Size of Int is:%d\n", sizeof(int));

    printf("Size of float is:%d\n", sizeof(b));
    printf("Size of float is:%d\n", sizeof(float));

    printf("Size of double is:%d\n", sizeof(c));
    printf("Size of double is:%d\n", sizeof(double));

    printf("Size of char is:%d\n", sizeof(ch));
    printf("Size of char is:%d\n", sizeof(char));

    return 0;
}
