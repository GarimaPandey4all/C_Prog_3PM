#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Variable and Constant

    int a = 10; //  declaration and initialization

    const int b = 30; // fixed - constant

    //int b; // declaration

    printf("A is: %d\n", a); // a= 10

    a = 20; // re-initialization

    printf("A is: %d\n", a);

    a = 50;

    printf("A is: %d\n", a);

    printf("B is: %d", b);

    //b = 50; // error

    return 0;
}
