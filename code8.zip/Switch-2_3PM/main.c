#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Menu Driven Program

    int choice;
    int a, b;
    int number;
    int temp;

    while(1) // while - 1 - true - infinite loop
    {
    printf("\n\nPress 1. X-OR Bitwise Operator\n");
    printf("Press 2. Addition\n");
    printf("Press 3. Even-Odd\n");
    printf("Press 4. Swapping\n");
    printf("Press 5. Exit\n");
    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:

        printf("Enter any value for a:");
        scanf("%d", &a);

        printf("Enter any value for b:");
        scanf("%d", &b);

        printf("X-OR is: %d\n", (a ^ b));

        break;

    case 2:

        printf("Enter any value for a:");
        scanf("%d", &a);

        printf("Enter any value for b:");
        scanf("%d", &b);

        printf("Addition is: %d\n", (a + b));

        break;

    case 3:

        printf("Enter any value:");
        scanf("%d", &number);

        ((number % 2) == 0) ? printf("Number is Even") : printf("Number is Odd");

        break;

    case 4:

        printf("Enter any value for a:");
        scanf("%d", &a);

        printf("Enter any value for b:");
        scanf("%d", &b);

        printf("Before Swapping the value of a=%d and b=%d", a, b);

        temp = a;
        a = b;
        b = temp;

        printf("After Swapping the value of a=%d and b=%d", a, b);

        break;

    case 5:

        exit(0);

    default:
        printf("Invalid Choice");
    }
    }

    return 0;
}
