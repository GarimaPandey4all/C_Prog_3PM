#include <stdio.h>
#include <stdlib.h>

//Swapping or exchange

//Swapping using third variable

int main()
{
    int a, b, temp;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Before Swapping the value of a=%d and b=%d.\n", a, b);

    //a = 4, b = 6

    temp = a; // a = 4, temp = 4
    a = b; // b = 6, a = 6
    b = temp; // b = 4

    // a = 6, b = 4

    printf("After Swapping the value of a=%d and b=%d.\n", a, b);

    return 0;
}
