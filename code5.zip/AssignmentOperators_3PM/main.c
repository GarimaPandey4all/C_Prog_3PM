#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum;

    printf("Enter any value for sum:");
    scanf("%d", &sum);

    sum *= 20; //sum = sum + 20; // shorthand

    printf("%d\n", sum);

    printf("%d", &sum); // & = address of operator

    return 0;
}
