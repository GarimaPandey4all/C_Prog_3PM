#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

//    printf("Before Swapping the value of a=%d and b=%d.\n", a, b);
//
//    //First Way: + and - Operators
//
//    // a = 4, b = 6
//
//    a = a + b; // a = 10
//    b = a - b; // 10 - 6 = 4, b = 4
//    a = a - b; // 10 - 4 = a = 6
//
//    printf("After Swapping the value of a=%d and b=%d.\n", a, b);

//    printf("Before Swapping the value of a=%d and b=%d.\n", a, b);
//
//    //Second Way: * and / Operators
//
//    // a = 4, b = 6
//
//    a = a * b; // a = 4 * 6 = 24
//    b = a / b; // b = 24/6 = 4
//    a = a / b; // a = 24/4 = 6
//
//    printf("After Swapping the value of a=%d and b=%d.\n", a, b);

    printf("Before Swapping the value of a=%d and b=%d.\n", a, b);

    //Third Way: X-OR (^) Operator

    // a = 4, b = 6

    a = a ^ b; // a = 4 ^ 6 = 2
    b = a ^ b; // b = 2 ^ 6 = 4
    a = a ^ b; // a = 2 ^ 4 = 6

    printf("After Swapping the value of a=%d and b=%d.\n", a, b);

    return 0;
}
