#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 1, y = 2;

    printf("x && y is:%d\n", (x && y));

    printf("x & y is:%d\n", (x & y));

    return 0;
}
