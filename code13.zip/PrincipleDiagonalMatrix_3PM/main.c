#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix[5][5], i, j, rows, columns;

    printf("Enter number of rows:");
    scanf("%d", &rows);

    printf("Enter number of columns:");
    scanf("%d", &columns);

    printf("Enter values in a Matrix:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("Values in Matrix are:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    printf("Principle Diagonal Matrix is:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            if(i == j)
            printf("%d\t", matrix[i][j]);
        }
    }

    return 0;
}
