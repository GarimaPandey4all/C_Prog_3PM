#include <stdio.h>
#include <stdlib.h>

/*
    Conditional/Ternary Operator- ? :

    Ternary - 3

        Condition        True : False

    (Expression-1) ?   Expression-2 : Expression-3

*/

int main()
{
    int number;

    printf("Enter any number:");
    scanf("%d", &number);

    ((number%2) == 0) ? printf("Number is Even") : printf("Number is Odd");

    return 0;
}
