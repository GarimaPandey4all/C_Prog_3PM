#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;

    a += 10; //Shorthand //a = a + 10;

    a /= 10; // a = a / 10;

    printf("%d", a);

    return 0;
}
