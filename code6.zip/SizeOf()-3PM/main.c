#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    float b;
    double c;
    char d;

    printf("Size of Int:%d\n", sizeof(a));
    printf("Size of Float:%d\n", sizeof(b));
    printf("Size of Double:%d\n", sizeof(c));
    printf("Size of Char:%d\n", sizeof(d));

    printf("Size of Int:%d\n", sizeof(int));

    return 0;
}
